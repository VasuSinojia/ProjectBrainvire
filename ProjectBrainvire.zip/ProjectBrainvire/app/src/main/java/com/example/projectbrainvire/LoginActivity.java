package com.example.projectbrainvire;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private EditText et_name;
    private EditText et_email;
    private EditText et_password;
    private Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);



        et_name = findViewById(R.id.et_name);
        et_email = findViewById(R.id.et_email);
        et_password = findViewById(R.id.et_password);
        btn_login = findViewById(R.id.btn_login);

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getName = et_name.getText().toString();
                String getEmail = et_email.getText().toString();
                String getPassword = et_password.getText().toString();
                String Expn =
                        "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if (getEmail.matches(Expn) && getEmail.length() > 0 && getPassword.length() > 0 && getName.length() > 0) {
//
                    Map<String,String> map = new HashMap<>();
                    map.put("Name",getName);
                    map.put("Email",getEmail);
                    db.collection("group").document().set(map);


                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                } else {
                    Toast.makeText(LoginActivity.this, "Please Enter Valid Details", Toast.LENGTH_SHORT).show();
                }
            }


        });
    }
}





